package com.familycontrol.child;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {
    
    private static final String TAG = "BootReceiver";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        
        Log.d(TAG, "Received broadcast: " + action);
        
        if (Intent.ACTION_BOOT_COMPLETED.equals(action) ||
            Intent.ACTION_MY_PACKAGE_REPLACED.equals(action) ||
            Intent.ACTION_PACKAGE_REPLACED.equals(action)) {
            
            try {
                // Start the monitoring service
                Intent serviceIntent = new Intent(context, MonitoringService.class);
                context.startForegroundService(serviceIntent);
                
                Log.d(TAG, "MonitoringService started from boot receiver");
                
            } catch (Exception e) {
                Log.e(TAG, "Error starting service from boot receiver", e);
            }
        }
    }
}

