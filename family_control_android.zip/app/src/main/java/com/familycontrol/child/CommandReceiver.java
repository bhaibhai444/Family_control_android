package com.familycontrol.child;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class CommandReceiver extends BroadcastReceiver {
    
    private static final String TAG = "CommandReceiver";
    public static final String ACTION_EXECUTE_COMMAND = "com.familycontrol.child.EXECUTE_COMMAND";
    public static final String EXTRA_COMMAND_TYPE = "command_type";
    public static final String EXTRA_COMMAND_DATA = "command_data";
    
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        
        Log.d(TAG, "Received broadcast: " + action);
        
        if (ACTION_EXECUTE_COMMAND.equals(action)) {
            String commandType = intent.getStringExtra(EXTRA_COMMAND_TYPE);
            String commandData = intent.getStringExtra(EXTRA_COMMAND_DATA);
            
            Log.d(TAG, "Executing command: " + commandType);
            
            try {
                executeCommand(context, commandType, commandData);
            } catch (Exception e) {
                Log.e(TAG, "Error executing command: " + commandType, e);
            }
        }
    }
    
    private void executeCommand(Context context, String commandType, String commandData) {
        switch (commandType) {
            case "capture_image":
                CameraManager cameraManager = new CameraManager(context);
                cameraManager.captureImage();
                break;
                
            case "record_audio":
                AudioManager audioManager = new AudioManager(context);
                audioManager.startRecording();
                break;
                
            case "start_camera":
                CameraManager cameraStreamManager = new CameraManager(context);
                cameraStreamManager.startCameraStream();
                break;
                
            case "stop_camera":
                // This would need to be handled by the service
                break;
                
            case "get_location":
                LocationManager locationManager = new LocationManager(context);
                locationManager.getCurrentLocation();
                break;
                
            default:
                Log.w(TAG, "Unknown command type: " + commandType);
        }
    }
    
    public static void sendCommand(Context context, String commandType, String commandData) {
        Intent intent = new Intent(ACTION_EXECUTE_COMMAND);
        intent.putExtra(EXTRA_COMMAND_TYPE, commandType);
        intent.putExtra(EXTRA_COMMAND_DATA, commandData);
        context.sendBroadcast(intent);
    }
}

