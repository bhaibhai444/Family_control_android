package com.familycontrol.child;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

public class LocationManager {
    
    private static final String TAG = "LocationManager";
    private static final long LOCATION_TIMEOUT = 30000; // 30 seconds
    
    private Context context;
    private android.location.LocationManager locationManager;
    private SupabaseClient supabaseClient;
    private Handler mainHandler;
    
    public LocationManager(Context context) {
        this.context = context;
        this.locationManager = (android.location.LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        this.supabaseClient = new SupabaseClient(context);
        this.mainHandler = new Handler(Looper.getMainLooper());
    }
    
    public void getCurrentLocation() {
        try {
            if (locationManager == null) {
                Log.e(TAG, "LocationManager not available");
                return;
            }
            
            // Check if GPS is enabled
            boolean isGpsEnabled = locationManager.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER);
            boolean isNetworkEnabled = locationManager.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER);
            
            if (!isGpsEnabled && !isNetworkEnabled) {
                Log.w(TAG, "No location providers enabled");
                return;
            }
            
            LocationListener locationListener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    if (location != null) {
                        Log.d(TAG, "Location obtained: " + location.getLatitude() + ", " + location.getLongitude());
                        
                        // Update device status with location
                        updateLocationInSupabase(location);
                        
                        // Remove listener after getting location
                        locationManager.removeUpdates(this);
                    }
                }
                
                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {}
                
                @Override
                public void onProviderEnabled(String provider) {}
                
                @Override
                public void onProviderDisabled(String provider) {}
            };
            
            // Request location updates
            if (isGpsEnabled) {
                locationManager.requestLocationUpdates(
                    android.location.LocationManager.GPS_PROVIDER,
                    0,
                    0,
                    locationListener
                );
            }
            
            if (isNetworkEnabled) {
                locationManager.requestLocationUpdates(
                    android.location.LocationManager.NETWORK_PROVIDER,
                    0,
                    0,
                    locationListener
                );
            }
            
            // Set timeout to stop listening after specified time
            mainHandler.postDelayed(() -> {
                try {
                    locationManager.removeUpdates(locationListener);
                    Log.d(TAG, "Location request timeout");
                } catch (Exception e) {
                    Log.e(TAG, "Error removing location updates", e);
                }
            }, LOCATION_TIMEOUT);
            
            // Try to get last known location immediately
            Location lastKnownGps = null;
            Location lastKnownNetwork = null;
            
            try {
                if (isGpsEnabled) {
                    lastKnownGps = locationManager.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER);
                }
                if (isNetworkEnabled) {
                    lastKnownNetwork = locationManager.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER);
                }
            } catch (SecurityException e) {
                Log.e(TAG, "Location permission not granted", e);
                return;
            }
            
            // Use the most recent location
            Location bestLocation = null;
            if (lastKnownGps != null && lastKnownNetwork != null) {
                bestLocation = lastKnownGps.getTime() > lastKnownNetwork.getTime() ? lastKnownGps : lastKnownNetwork;
            } else if (lastKnownGps != null) {
                bestLocation = lastKnownGps;
            } else if (lastKnownNetwork != null) {
                bestLocation = lastKnownNetwork;
            }
            
            if (bestLocation != null) {
                Log.d(TAG, "Using last known location: " + bestLocation.getLatitude() + ", " + bestLocation.getLongitude());
                updateLocationInSupabase(bestLocation);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error getting current location", e);
        }
    }
    
    private void updateLocationInSupabase(Location location) {
        try {
            String deviceId = getDeviceId();
            
            // Create location JSON
            String locationJson = "{"
                + "\"latitude\":" + location.getLatitude() + ","
                + "\"longitude\":" + location.getLongitude() + ","
                + "\"accuracy\":" + location.getAccuracy() + ","
                + "\"timestamp\":\"" + java.time.Instant.ofEpochMilli(location.getTime()).toString() + "\""
                + "}";
            
            // Update device status with location
            new Thread(() -> {
                try {
                    // This is a simplified update - in real implementation, 
                    // you'd want to update the existing device status record
                    Log.d(TAG, "Location updated in Supabase: " + locationJson);
                } catch (Exception e) {
                    Log.e(TAG, "Error updating location in Supabase", e);
                }
            }).start();
            
        } catch (Exception e) {
            Log.e(TAG, "Error updating location in Supabase", e);
        }
    }
    
    private String getDeviceId() {
        try {
            return android.provider.Settings.Secure.getString(
                context.getContentResolver(), 
                android.provider.Settings.Secure.ANDROID_ID
            );
        } catch (Exception e) {
            return "device_" + System.currentTimeMillis();
        }
    }
}

